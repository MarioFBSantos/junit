
package Fatura;


public class FaturaTest {
    
}
