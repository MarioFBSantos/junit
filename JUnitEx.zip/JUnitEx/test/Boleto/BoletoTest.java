package Boleto;


import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotSame;
import static junit.framework.Assert.assertTrue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;
import org.junit.Before;
import org.junit.Test;
import produto.Produto;


public class BoletoTest {
	
	Produto boleto;
	
	@Before
	public void inicializa() {
		boleto = new Produto("Introdu��o ao Teste de Software", 100.00);
	}
	
	@Test
	public void testCriaProduto() {
		
				assertEquals("Introdu��o ao Teste de Software", livro.getNome());
				assertTrue(100.00 == livro.getPreco());						
				
	}
	