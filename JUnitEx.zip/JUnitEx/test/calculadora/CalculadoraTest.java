package calculadora;


import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertTrue;
import static junit.framework.Assert.fail;



//import static junit.framework.Assert.assertThrows;
import org.junit.Before;
import org.junit.Test;

//@DisplayName("Classe para teste da calculadora")
public class CalculadoraTest {
	
	private Calculadora calc;
	
	@Before
	public void inicializa() {
		calc = new Calculadora();
	}
	
	@Test
	public void testSomaDoisNumeros() {
		int soma = calc.soma(4, 5);		
		assertEquals(9, soma);		
	}
	
	@Test
	public void testDivisaoDoisNumeros() {
		int divisao = calc.divisao(8, 4);
		assertTrue(divisao == 2);
	}
        
        @Test
        public void testeMultiplica(){
               int mult = calc.multiplicacao(2, 4);
               assertEquals(8, mult);
        }
        
        @Test
        public void testSomatoria(){
            int smt = calc.somatoria(2);
            assertEquals(3, smt);
        }
        
        @Test
        public void testSubtracao(){
            int sub = calc.subtracao(3, 1);
            assertEquals(2, sub);
        }
        
        @Test
        public void testPositivo(){
            boolean pos = calc.ehPositivo(1);
            assertTrue(pos);
        }
        
        @Test
        public void testCompara(){
            int comp = calc.compara(10, 10);
            assertTrue(comp == 0);
        }
        
        
        
	
	@Test
	public void testDivisaoPorZero() {
		try {
			int divisao = calc.divisao(8, 0);
			fail("Exce��o n�o lan�ada");
		}catch (ArithmeticException e) {
			assertEquals("/ by zero", e.getMessage());
		}		
	}
	
}
